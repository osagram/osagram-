const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

let users = [
  { id: '1', name: 'John Doe', phoneNumber: '+1234567890', online: true },
  { id: '2', name: 'Jane Smith', phoneNumber: '+0987654321', online: false }
];

let messages = [];

io.on('connection', (socket) => {
  console.log('User connected to Osagram:', socket.id);

  socket.on('join', (userId) => {
    socket.join(userId);
    console.log(`User ${userId} joined Osagram`);
  });

  socket.on('sendMessage', (data) => {
    const message = {
      id: Date.now().toString(),
      chatId: data.chatId,
      senderId: data.senderId,
      content: data.content,
      type: data.type || 'text',
      timestamp: new Date(),
      status: 'sent'
    };

    messages.push(message);

    socket.to(data.receiverId).emit('newMessage', message);
    socket.emit('messageSent', message);
  });

  socket.on('typing', (data) => {
    socket.to(data.receiverId).emit('userTyping', {
      userId: data.senderId,
      isTyping: data.isTyping
    });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected from Osagram:', socket.id);
  });
});

app.get('/api/users', (req, res) => {
  res.json(users);
});

app.get('/api/messages/:chatId', (req, res) => {
  const chatMessages = messages.filter(msg => msg.chatId === req.params.chatId);
  res.json(chatMessages);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Osagram server running on port ${PORT}`);
});
