import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'react-native';
import ChatsScreen from './src/screens/ChatsScreen';
import ChatScreen from './src/screens/ChatScreen';
import ContactsScreen from './src/screens/ContactsScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <Stack.Navigator initialRouteName="Chats">
        <Stack.Screen name="Chats" component={ChatsScreen} options={{ title: 'Osagram' }} />
        <Stack.Screen name="Chat" component={ChatScreen} options={({ route }) => ({ title: route.params?.contactName || 'Chat' })} />
        <Stack.Screen name="Contacts" component={ContactsScreen} options={{ title: 'Select Contact' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
